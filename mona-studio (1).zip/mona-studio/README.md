# MONA Studio — Website

A single static website for MONA Studio (photography & creative studio, Mwea, Kirinyaga County, Kenya).

## What's included
- `index.html` — all page content (hero, about, services, packages, gallery, booking process, contact)
- `styles.css` — visual design
- `script.js` — gallery upload/lightbox logic
- `images/hero.png` — hero illustration

## Gallery upload
The "Upload photos" button in the Gallery section lets you add images directly in the browser.
Photos are stored in that browser's local storage (`localStorage`), so:
- They persist between visits **on the same device/browser**.
- They are **not shared** between visitors — each person who opens the site has their own gallery.
- Use "Clear all" to wipe stored photos.

If you want one shared gallery that everyone sees (e.g. fed by you uploading real shoot photos for all visitors), that needs a small backend or storage service — happy to help wire that up if you want it later (Vercel Blob, Cloudinary, or a simple database all work well).

## Deploy: GitHub + Vercel

### 1. Push to GitHub
```bash
cd mona-studio
git init
git add .
git commit -m "Initial MONA Studio site"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```
(Create the empty repo on GitHub first at https://github.com/new — don't initialize it with a README so there's no conflict.)

### 2. Deploy on Vercel
1. Go to https://vercel.com and sign in (you can sign in with your GitHub account).
2. Click **Add New… → Project**.
3. Select the GitHub repo you just pushed.
4. Framework preset: **Other** (it's a static site — no build step needed).
5. Leave Build Command and Output Directory blank.
6. Click **Deploy**.

Vercel will give you a live URL (e.g. `mona-studio.vercel.app`). Every time you push to `main` on GitHub, Vercel will redeploy automatically.

### Custom domain (optional)
In the Vercel project → **Settings → Domains**, add your own domain (e.g. `monastudio.co.ke`) and follow the DNS instructions shown.
